<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QFileDialogCustom</name>
    <message>
        <location filename="QFileDialogCustom.py" line="60"/>
        <source>Already existing file</source>
        <translation>El archivo ya existe</translation>
    </message>
    <message>
        <location filename="QFileDialogCustom.py" line="61"/>
        <source>The &lt;b&gt;{}&lt;/b&gt; file is already existing, overwrite it?</source>
        <translation>El archivo &lt;b&gt;{}&lt;/b&gt; ya existe, ¿sobrescribirlo?</translation>
    </message>
</context>
</TS>
