<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>QFileDialogCustom</name>
    <message>
        <location filename="QFileDialogCustom.py" line="60"/>
        <source>Already existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QFileDialogCustom.py" line="61"/>
        <source>The &lt;b&gt;{}&lt;/b&gt; file is already existing, overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
