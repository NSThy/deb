<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>QFileDialogCustom</name>
    <message>
        <location filename="QFileDialogCustom.py" line="60"/>
        <source>Already existing file</source>
        <translation>Fichier déjà existant</translation>
    </message>
    <message>
        <location filename="QFileDialogCustom.py" line="61"/>
        <source>The &lt;b&gt;{}&lt;/b&gt; file is already existing, overwrite it?</source>
        <translation>Le fichier &lt;b&gt;{}&lt;/b&gt; existe déjà, faut-il l'écraser ?</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="QFileDialogCustom.py" line="134"/>
        <source>Already existing file</source>
        <translation type="obsolete">Fichier déjà existant</translation>
    </message>
    <message>
        <location filename="QFileDialogCustom.py" line="134"/>
        <source>The &lt;b&gt;{}&lt;/b&gt; file is already existing, overwrite it?</source>
        <translation type="obsolete">Le fichier &lt;b&gt;{}&lt;/b&gt; existe déjà, faut-il l'écraser ?</translation>
    </message>
</context>
</TS>
